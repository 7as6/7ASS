import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import AdminPanel from "./components/AdminPanel";
import GameHub from "./components/GameHub";
import Settings from "./components/Settings";

export default function App() {
  const isLoggedIn = useQuery(api.auth.isAuthenticated);
  const isAdmin = useQuery(api.admin.isAdmin);

  if (isLoggedIn === undefined) {
    return <div>جاري التحميل...</div>;
  }

  if (!isLoggedIn) {
    return <SignInForm />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">مركز الألعاب</h1>
          <SignOutButton />
        </div>

        {/* لوحة المشرفين */}
        {isAdmin && <AdminPanel />}

        {/* مركز الألعاب */}
        <GameHub />

        {/* الإعدادات */}
        <Settings />
      </div>
    </div>
  );
}
