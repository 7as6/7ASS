import { useState } from "react";
import TicTacToe from "./games/TicTacToe";
import Checkers from "./games/Checkers";
import Quiz from "./games/Quiz";
import Memory from "./games/Memory";

export default function GameHub() {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  const games = [
    { id: "tictactoe", name: "إكس أو", component: TicTacToe },
    { id: "checkers", name: "الداما", component: Checkers },
    { id: "quiz", name: "جاوب جوابك", component: Quiz },
    { id: "memory", name: "لعبة الذاكرة", component: Memory }
  ];

  if (selectedGame) {
    const Game = games.find(g => g.id === selectedGame)?.component;
    if (Game) {
      return (
        <div className="space-y-4">
          <button
            onClick={() => setSelectedGame(null)}
            className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
          >
            العودة للقائمة الرئيسية
          </button>
          <Game />
        </div>
      );
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {games.map(game => (
        <button
          key={game.id}
          onClick={() => setSelectedGame(game.id)}
          className="bg-white/10 hover:bg-white/20 backdrop-blur-sm p-8 rounded-xl text-white transition-all transform hover:scale-105"
        >
          <h3 className="text-2xl font-bold mb-2">{game.name}</h3>
        </button>
      ))}
    </div>
  );
}
