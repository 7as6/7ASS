import { useState } from 'react';
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";

export default function AdminPanel() {
  const isAdmin = useQuery(api.admin.isAdmin);
  const admins = useQuery(api.admin.listAdmins);
  const addAdmin = useMutation(api.admin.addAdmin);
  const removeAdmin = useMutation(api.admin.removeAdmin);
  const [newAdminId, setNewAdminId] = useState("");

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="bg-white/5 rounded-lg p-6 mt-4">
      <h2 className="text-2xl font-bold text-white mb-4">لوحة المشرفين</h2>
      
      <div className="space-y-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={newAdminId}
            onChange={(e) => setNewAdminId(e.target.value)}
            placeholder="معرف المستخدم"
            className="bg-white/10 text-white px-3 py-2 rounded-lg flex-1"
          />
          <button
            onClick={() => {
              if (newAdminId) {
                addAdmin({ userId: newAdminId });
                setNewAdminId("");
              }
            }}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
          >
            إضافة مشرف
          </button>
        </div>

        {admins && admins.length > 0 && (
          <div className="mt-4">
            <h3 className="text-xl font-bold text-white mb-2">قائمة المشرفين</h3>
            <div className="space-y-2">
              {admins.map((admin) => (
                <div key={admin._id} className="flex justify-between items-center bg-white/10 p-3 rounded-lg">
                  <span className="text-white">{admin.userId}</span>
                  <button
                    onClick={() => removeAdmin({ userId: admin.userId })}
                    className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg"
                  >
                    إزالة
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
