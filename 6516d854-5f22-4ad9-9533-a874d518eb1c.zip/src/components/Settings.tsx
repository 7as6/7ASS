import { useState } from 'react';
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

export default function Settings() {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="mt-8">
      {/* زر الإعدادات */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg"
      >
        <span>⚙️</span>
        <span>الإعدادات</span>
      </button>

      {/* قائمة الإعدادات */}
      {isOpen && (
        <div className="mt-4 bg-white/5 rounded-lg p-6">
          <h2 className="text-2xl font-bold text-white mb-6">الإعدادات</h2>
          
          <div className="space-y-6">
            {/* إعدادات الصوت */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">الصوت</h3>
              <label className="flex items-center gap-4 text-white">
                <span>مستوى الصوت</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  defaultValue="50"
                  className="w-48"
                />
              </label>
            </div>

            {/* إعدادات اللغة */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">اللغة</h3>
              <select className="bg-white/10 text-white px-4 py-2 rounded-lg w-48">
                <option value="ar">العربية</option>
              </select>
            </div>

            {/* إعدادات المظهر */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">المظهر</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-white">
                  <input type="checkbox" defaultChecked />
                  <span>تأثيرات الحركة</span>
                </label>
                <label className="flex items-center gap-2 text-white">
                  <input type="checkbox" defaultChecked />
                  <span>الوضع الليلي</span>
                </label>
              </div>
            </div>

            {/* إعدادات الإشعارات */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-3">الإشعارات</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-white">
                  <input type="checkbox" defaultChecked />
                  <span>إشعارات اللعب</span>
                </label>
                <label className="flex items-center gap-2 text-white">
                  <input type="checkbox" defaultChecked />
                  <span>إشعارات الرسائل</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
