import { useState } from 'react';

export default function TicTacToe() {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);

  const calculateWinner = (squares: Array<string | null>) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // أفقي
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // عمودي
      [0, 4, 8], [2, 4, 6] // قطري
    ];

    for (const [a, b, c] of lines) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  };

  const handleClick = (i: number) => {
    if (winner || board[i]) return;

    const newBoard = [...board];
    newBoard[i] = xIsNext ? 'X' : 'O';
    setBoard(newBoard);
    setXIsNext(!xIsNext);

    const newWinner = calculateWinner(newBoard);
    if (newWinner) {
      setWinner(newWinner);
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setXIsNext(true);
    setWinner(null);
  };

  const renderSquare = (i: number) => (
    <button
      className={`w-20 h-20 text-4xl font-bold rounded-lg transition-colors
        ${board[i] ? 'bg-purple-600' : 'bg-white/10 hover:bg-white/20'}`}
      onClick={() => handleClick(i)}
      disabled={!!winner || !!board[i]}
    >
      {board[i]}
    </button>
  );

  const status = winner
    ? `الفائز: ${winner}`
    : board.every(square => square)
    ? "تعادل!"
    : `اللاعب التالي: ${xIsNext ? 'X' : 'O'}`;

  return (
    <div className="flex flex-col items-center space-y-4">
      <h2 className="text-2xl font-bold text-white mb-4">لعبة إكس أو</h2>
      <div className="mb-4 text-white text-xl">{status}</div>
      <div className="grid grid-cols-3 gap-2">
        {[0, 1, 2].map(row => (
          <div key={row} className="flex gap-2">
            {[0, 1, 2].map(col => renderSquare(row * 3 + col))}
          </div>
        ))}
      </div>
      <button
        onClick={resetGame}
        className="mt-4 bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
      >
        لعبة جديدة
      </button>
    </div>
  );
}
