import { useState, useEffect } from 'react';
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { Id } from "../../../convex/_generated/dataModel";

export default function SpeedQuiz() {
  const [roundId, setRoundId] = useState<Id<"speedQuizRounds"> | null>(null);
  const createRound = useMutation(api.games.createSpeedQuizRound);
  const joinRound = useMutation(api.games.joinSpeedQuizRound);
  const submitAnswer = useMutation(api.games.submitSpeedQuizAnswer);
  const round = useQuery(api.games.getSpeedQuizRound, roundId ? { roundId } : "skip");
  const activeRounds = useQuery(api.games.getActiveRounds) || [];

  const handleCreateRound = async () => {
    const newRoundId = await createRound({ category: "food" });
    setRoundId(newRoundId);
  };

  const handleJoinRound = async (id: Id<"speedQuizRounds">) => {
    await joinRound({ roundId: id });
    setRoundId(id);
  };

  const handleAnswerSubmit = async (itemName: string) => {
    if (!roundId) return;
    try {
      await submitAnswer({ roundId, itemName });
    } catch (error) {
      console.error(error);
    }
  };

  if (!roundId) {
    return (
      <div className="flex flex-col items-center space-y-4">
        <h2 className="text-2xl font-bold text-white mb-4">جاوب جوابك</h2>
        <button
          onClick={handleCreateRound}
          className="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-lg transition-colors w-full"
        >
          إنشاء جولة جديدة
        </button>
        
        {activeRounds.length > 0 && (
          <div className="w-full">
            <h3 className="text-xl font-bold text-white mb-2">الجولات المتاحة</h3>
            <div className="space-y-2">
              {activeRounds.map((r) => (
                <button
                  key={r._id}
                  onClick={() => handleJoinRound(r._id)}
                  className="bg-white/10 hover:bg-white/20 text-white w-full py-2 px-4 rounded-lg transition-colors"
                >
                  جولة {r.category} - {r.players.length} لاعبين
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  if (!round) {
    return <div className="text-white">جاري التحميل...</div>;
  }

  return (
    <div className="flex flex-col items-center space-y-4">
      <h2 className="text-2xl font-bold text-white mb-4">جاوب جوابك</h2>
      
      <div className="text-white mb-4">
        {round.status === "waiting" ? (
          <div>في انتظار اللاعبين ({round.players.length}/4)</div>
        ) : round.status === "active" ? (
          <div>الجولة جارية!</div>
        ) : (
          <div>انتهت الجولة!</div>
        )}
      </div>

      {round.status === "active" && (
        <div className="grid grid-cols-2 gap-4 w-full max-w-md">
          {round.items.map((item) => {
            const isAnswered = round.answers.some(a => a.itemName === item.name);
            return (
              <button
                key={item.name}
                onClick={() => handleAnswerSubmit(item.name)}
                disabled={isAnswered}
                className={`p-4 rounded-lg text-white font-medium transition-colors
                  ${isAnswered ? 'bg-green-600' : 'bg-white/10 hover:bg-white/20'}
                `}
              >
                {item.name} ({item.points} نقطة)
              </button>
            );
          })}
        </div>
      )}

      {round.answers.length > 0 && (
        <div className="mt-8 w-full max-w-md">
          <h3 className="text-xl font-bold text-white mb-4">النتائج</h3>
          <div className="bg-white/10 rounded-lg p-4">
            {round.answers.map((answer) => (
              <div key={answer._id} className="flex justify-between items-center text-white mb-2">
                <span>{answer.username}</span>
                <span>{answer.itemName} - {answer.points} نقطة</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
