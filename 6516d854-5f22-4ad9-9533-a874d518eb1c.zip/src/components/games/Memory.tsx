import { useState, useEffect } from "react";

export default function Memory() {
  const [cards, setCards] = useState<Array<{ id: number; value: string; flipped: boolean; matched: boolean }>>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matches, setMatches] = useState(0);

  const symbols = ["🌟", "🎈", "🎨", "🎭", "🎪", "🎯", "🎲", "🎮"];

  useEffect(() => {
    initializeGame();
  }, []);

  const initializeGame = () => {
    const shuffledCards = [...symbols, ...symbols]
      .map((value, index) => ({
        id: index,
        value,
        flipped: false,
        matched: false
      }))
      .sort(() => Math.random() - 0.5);
    setCards(shuffledCards);
    setFlippedCards([]);
    setMatches(0);
  };

  const handleCardClick = (id: number) => {
    if (flippedCards.length === 2) return;
    if (cards[id].matched || cards[id].flipped) return;

    const newCards = [...cards];
    newCards[id].flipped = true;
    setCards(newCards);

    const newFlippedCards = [...flippedCards, id];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      const [firstId, secondId] = newFlippedCards;
      if (cards[firstId].value === cards[secondId].value) {
        newCards[firstId].matched = true;
        newCards[secondId].matched = true;
        setCards(newCards);
        setFlippedCards([]);
        setMatches(matches + 1);
      } else {
        setTimeout(() => {
          newCards[firstId].flipped = false;
          newCards[secondId].flipped = false;
          setCards(newCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <h2 className="text-2xl font-bold text-white mb-4">لعبة الذاكرة</h2>
      <div className="grid grid-cols-4 gap-4">
        {cards.map((card) => (
          <button
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            className={`w-20 h-20 rounded-lg text-4xl flex items-center justify-center transition-all transform hover:scale-105
              ${card.flipped || card.matched ? 'bg-purple-600' : 'bg-white/10'}`}
            disabled={card.matched}
          >
            {(card.flipped || card.matched) ? card.value : '?'}
          </button>
        ))}
      </div>
      <button
        onClick={initializeGame}
        className="mt-4 bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
      >
        لعبة جديدة
      </button>
    </div>
  );
}
