import { useState } from 'react';
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { Id } from "../../../convex/_generated/dataModel";

export default function Checkers() {
  const [gameId, setGameId] = useState<Id<"checkers"> | null>(null);
  const [selectedPiece, setSelectedPiece] = useState<number[] | null>(null);
  
  const createGame = useMutation(api.games.createCheckersGame);
  const joinGame = useMutation(api.games.joinCheckersGame);
  const makeMove = useMutation(api.games.makeCheckersMove);
  const game = useQuery(api.games.getCheckersGame, gameId ? { gameId } : "skip");

  const handleCreateGame = async () => {
    const newGameId = await createGame();
    setGameId(newGameId);
  };

  const handleJoinGame = async (id: Id<"checkers">) => {
    await joinGame({ gameId: id });
    setGameId(id);
  };

  const handleCellClick = async (rowIndex: number, colIndex: number) => {
    if (!gameId || !game) return;

    if (selectedPiece) {
      try {
        await makeMove({
          gameId,
          from: selectedPiece,
          to: [rowIndex, colIndex],
        });
        setSelectedPiece(null);
      } catch (error) {
        console.error(error);
        setSelectedPiece(null);
      }
    } else {
      if (game.board[rowIndex][colIndex] !== 0) {
        setSelectedPiece([rowIndex, colIndex]);
      }
    }
  };

  if (!gameId) {
    return (
      <div className="text-center">
        <button
          onClick={handleCreateGame}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
        >
          إنشاء لعبة جديدة
        </button>
      </div>
    );
  }

  if (!game) {
    return <div className="text-white">جاري التحميل...</div>;
  }

  return (
    <div className="flex flex-col items-center">
      <div className="mb-4 text-white">
        {game.status === "waiting" ? (
          <div>في انتظار اللاعب الثاني...</div>
        ) : (
          <div>دور اللاعب {game.currentPlayer}</div>
        )}
      </div>

      <div className="grid grid-cols-8 gap-1 bg-brown-800 p-2 rounded-lg">
        {game.board.map((row: number[], rowIndex: number) => (
          <div key={rowIndex} className="flex">
            {row.map((cell: number, colIndex: number) => (
              <div
                key={`${rowIndex}-${colIndex}`}
                onClick={() => handleCellClick(rowIndex, colIndex)}
                className={`
                  w-12 h-12 flex items-center justify-center cursor-pointer
                  ${(rowIndex + colIndex) % 2 === 0 ? 'bg-brown-200' : 'bg-brown-600'}
                  ${selectedPiece && selectedPiece[0] === rowIndex && selectedPiece[1] === colIndex ? 'ring-2 ring-yellow-400' : ''}
                `}
              >
                {cell !== 0 && (
                  <div
                    className={`
                      w-8 h-8 rounded-full
                      ${cell === 1 ? 'bg-red-600' : 'bg-black'}
                      ${cell === 1 ? 'border-red-400' : 'border-gray-600'}
                      border-2
                    `}
                  />
                )}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
