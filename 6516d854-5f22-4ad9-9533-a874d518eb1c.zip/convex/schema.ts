import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

export default defineSchema({
  ...authTables,
  admins: defineTable({
    userId: v.string(),
    role: v.string(),
  }).index("by_user", ["userId"]),
  speedQuizRounds: defineTable({
    category: v.string(),
    items: v.array(
      v.object({
        name: v.string(),
        points: v.number(),
      })
    ),
    status: v.string(),
    players: v.array(v.string()),
    startTime: v.optional(v.number()),
  }).index("by_status", ["status"]),
  speedQuizAnswers: defineTable({
    roundId: v.id("speedQuizRounds"),
    userId: v.string(),
    username: v.string(),
    itemName: v.string(),
    answeredAt: v.number(),
    points: v.number(),
  }).index("by_round", ["roundId"]),
  checkers: defineTable({
    gameId: v.string(),
    board: v.array(v.array(v.number())),
    currentPlayer: v.number(),
    players: v.array(v.string()),
    status: v.string(),
    lastMove: v.optional(
      v.object({
        from: v.array(v.number()),
        to: v.array(v.number()),
      })
    ),
  }),
});
