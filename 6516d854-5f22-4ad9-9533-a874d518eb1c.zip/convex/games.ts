import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { Id } from "./_generated/dataModel";

// ألعاب السرعة
const categories = {
  food: {
    name: "الطعام",
    items: [
      { name: "طماطم", points: 50 },
      { name: "خيار", points: 30 },
      { name: "بصل", points: 40 },
      { name: "ثوم", points: 60 },
      { name: "جزر", points: 45 },
      { name: "بطاطس", points: 35 },
      { name: "باذنجان", points: 55 },
      { name: "فلفل", points: 50 },
    ]
  },
  animals: {
    name: "الحيوانات",
    items: [
      { name: "أسد", points: 50 },
      { name: "نمر", points: 60 },
      { name: "زرافة", points: 40 },
      { name: "فيل", points: 30 },
      { name: "قرد", points: 45 },
      { name: "دب", points: 55 },
      { name: "ثعلب", points: 50 },
      { name: "ذئب", points: 65 },
    ]
  },
};

export const createSpeedQuizRound = mutation({
  args: {
    category: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const categoryData = categories[args.category as keyof typeof categories];
    if (!categoryData) throw new Error("الفئة غير موجودة");

    const roundId = await ctx.db.insert("speedQuizRounds", {
      category: args.category,
      items: categoryData.items,
      status: "waiting",
      players: [userId],
    });

    return roundId;
  },
});

export const joinSpeedQuizRound = mutation({
  args: {
    roundId: v.id("speedQuizRounds"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const round = await ctx.db.get(args.roundId);
    if (!round) throw new Error("الجولة غير موجودة");
    if (round.status !== "waiting") throw new Error("الجولة مكتملة");
    if (round.players.includes(userId)) throw new Error("أنت بالفعل في الجولة");

    if (round.players.length >= 4) {
      await ctx.db.patch(args.roundId, {
        players: [...round.players, userId],
        status: "active",
        startTime: Date.now(),
      });
    } else {
      await ctx.db.patch(args.roundId, {
        players: [...round.players, userId],
      });
    }
  },
});

export const submitSpeedQuizAnswer = mutation({
  args: {
    roundId: v.id("speedQuizRounds"),
    itemName: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const user = await ctx.db.get(userId);
    if (!user) throw new Error("المستخدم غير موجود");

    const round = await ctx.db.get(args.roundId);
    if (!round) throw new Error("الجولة غير موجودة");
    if (round.status !== "active") throw new Error("الجولة غير نشطة");

    const item = round.items.find(i => i.name === args.itemName);
    if (!item) throw new Error("الإجابة غير صحيحة");

    const existing = await ctx.db
      .query("speedQuizAnswers")
      .withIndex("by_round", (q) => q.eq("roundId", args.roundId))
      .filter((q) => q.eq("itemName", args.itemName))
      .first();
    
    if (existing) throw new Error("تم اختيار هذه الإجابة مسبقاً");

    await ctx.db.insert("speedQuizAnswers", {
      roundId: args.roundId,
      userId,
      username: user.name || "لاعب",
      itemName: args.itemName,
      answeredAt: Date.now(),
      points: item.points,
    });

    const answers = await ctx.db
      .query("speedQuizAnswers")
      .withIndex("by_round", (q) => q.eq("roundId", args.roundId))
      .collect();

    if (answers.length === round.items.length) {
      await ctx.db.patch(args.roundId, {
        status: "finished",
      });
    }
  },
});

export const getSpeedQuizRound = query({
  args: {
    roundId: v.id("speedQuizRounds"),
  },
  handler: async (ctx, args) => {
    const round = await ctx.db.get(args.roundId);
    if (!round) throw new Error("الجولة غير موجودة");

    const answers = await ctx.db
      .query("speedQuizAnswers")
      .withIndex("by_round", (q) => q.eq("roundId", args.roundId))
      .collect();

    return {
      ...round,
      answers,
    };
  },
});

export const getActiveRounds = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("speedQuizRounds")
      .withIndex("by_status", (q) => q.eq("status", "waiting"))
      .collect();
  },
});

// لعبة الداما
export const createCheckersGame = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    // إنشاء لوحة الداما الأولية
    const initialBoard = Array(8).fill(null).map((_, row) => {
      return Array(8).fill(null).map((_, col) => {
        if (row < 3 && (row + col) % 2 === 1) return 1; // قطع اللاعب 1
        if (row > 4 && (row + col) % 2 === 1) return 2; // قطع اللاعب 2
        return 0; // مربع فارغ
      });
    });

    const gameId = await ctx.db.insert("checkers", {
      gameId: Math.random().toString(36).substring(2, 15),
      board: initialBoard,
      currentPlayer: 1,
      players: [userId],
      status: "waiting",
    });

    return gameId;
  },
});

export const joinCheckersGame = mutation({
  args: {
    gameId: v.id("checkers"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const game = await ctx.db.get(args.gameId);
    if (!game) throw new Error("اللعبة غير موجودة");
    if (game.status !== "waiting") throw new Error("اللعبة مكتملة");
    if (game.players.includes(userId)) throw new Error("أنت بالفعل في اللعبة");

    await ctx.db.patch(args.gameId, {
      players: [...game.players, userId],
      status: "active",
    });
  },
});

export const makeCheckersMove = mutation({
  args: {
    gameId: v.id("checkers"),
    from: v.array(v.number()),
    to: v.array(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول");

    const game = await ctx.db.get(args.gameId);
    if (!game) throw new Error("اللعبة غير موجودة");
    if (game.status !== "active") throw new Error("اللعبة غير نشطة");

    const playerIndex = game.players.indexOf(userId);
    if (playerIndex === -1) throw new Error("لست لاعباً في هذه اللعبة");
    if (playerIndex + 1 !== game.currentPlayer) throw new Error("ليس دورك");

    // تنفيذ الحركة
    const newBoard = JSON.parse(JSON.stringify(game.board));
    const [fromRow, fromCol] = args.from;
    const [toRow, toCol] = args.to;

    // التحقق من صحة الحركة
    if (!isValidMove(newBoard, fromRow, fromCol, toRow, toCol, game.currentPlayer)) {
      throw new Error("حركة غير صالحة");
    }

    // تحريك القطعة
    newBoard[toRow][toCol] = newBoard[fromRow][fromCol];
    newBoard[fromRow][fromCol] = 0;

    // إذا كان هناك قطعة تم أكلها
    if (Math.abs(fromRow - toRow) === 2) {
      const midRow = (fromRow + toRow) / 2;
      const midCol = (fromCol + toCol) / 2;
      newBoard[midRow][midCol] = 0;
    }

    await ctx.db.patch(args.gameId, {
      board: newBoard,
      currentPlayer: game.currentPlayer === 1 ? 2 : 1,
      lastMove: { from: args.from, to: args.to },
    });
  },
});

export const getCheckersGame = query({
  args: {
    gameId: v.id("checkers"),
  },
  handler: async (ctx, args) => {
    const game = await ctx.db.get(args.gameId);
    if (!game) throw new Error("اللعبة غير موجودة");
    return game;
  },
});

// دالة مساعدة للتحقق من صحة الحركة
function isValidMove(board: number[][], fromRow: number, fromCol: number, toRow: number, toCol: number, currentPlayer: number): boolean {
  // التحقق من أن المربع المستهدف فارغ
  if (board[toRow][toCol] !== 0) return false;

  // التحقق من أن القطعة المتحركة تنتمي للاعب الحالي
  if (board[fromRow][fromCol] !== currentPlayer) return false;

  // التحقق من أن الحركة قطرية
  if (Math.abs(fromCol - toCol) !== Math.abs(fromRow - toRow)) return false;

  // التحقق من أن الحركة في الاتجاه الصحيح
  if (currentPlayer === 1 && toRow < fromRow) return false;
  if (currentPlayer === 2 && toRow > fromRow) return false;

  // التحقق من المسافة (إما خطوة واحدة أو قفزة فوق قطعة)
  const distance = Math.abs(fromRow - toRow);
  if (distance !== 1 && distance !== 2) return false;

  // إذا كانت قفزة، تحقق من وجود قطعة للخصم
  if (distance === 2) {
    const midRow = (fromRow + toRow) / 2;
    const midCol = (fromCol + toCol) / 2;
    const opponent = currentPlayer === 1 ? 2 : 1;
    if (board[midRow][midCol] !== opponent) return false;
  }

  return true;
}
