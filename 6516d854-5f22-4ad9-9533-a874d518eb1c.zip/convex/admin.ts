import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// قائمة المشرفين الأساسيين
const SUPER_ADMINS = [
  "4f0d-9b74-f16ef2df9cbc", // المشرف الأساسي
];

export const isAdmin = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return false;

    // التحقق من المشرفين الأساسيين
    if (SUPER_ADMINS.includes(userId)) return true;

    // التحقق من قاعدة البيانات
    const admin = await ctx.db
      .query("admins")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return !!admin;
  },
});

export const listAdmins = query({
  args: {},
  handler: async (ctx) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) throw new Error("يجب تسجيل الدخول");

    if (!SUPER_ADMINS.includes(currentUserId)) {
      throw new Error("غير مصرح لك بعرض قائمة المشرفين");
    }

    const admins = await ctx.db.query("admins").collect();
    return admins;
  },
});

export const addAdmin = mutation({
  args: {
    userId: v.string(),
  },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) throw new Error("يجب تسجيل الدخول");

    if (!SUPER_ADMINS.includes(currentUserId)) {
      throw new Error("غير مصرح لك بإضافة مشرفين");
    }

    await ctx.db.insert("admins", {
      userId: args.userId,
      role: "admin",
    });
  },
});

export const removeAdmin = mutation({
  args: {
    userId: v.string(),
  },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    if (!currentUserId) throw new Error("يجب تسجيل الدخول");

    if (!SUPER_ADMINS.includes(currentUserId)) {
      throw new Error("غير مصرح لك بإزالة مشرفين");
    }

    const adminToRemove = await ctx.db
      .query("admins")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .first();

    if (adminToRemove) {
      await ctx.db.delete(adminToRemove._id);
    }
  },
});
